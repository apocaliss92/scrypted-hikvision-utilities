# Hikvision reolink videoclips

https://github.com/apocaliss92/scrypted-hikvision-utilities - For requests and bugs

This plugin allows hikvision cameras to provide onboard stored videoclips